package com.test.employee.bean;

import lombok.Data;

@Data
public class sample {

	private int id;
}
